#define WIFI_SSID "boas"
#define WIFI_PASS "123123123"

#define COAP_DEFAULT_TIME_SEC 5
#define COAP_DEFAULT_TIME_USEC 0

#define AE_NAME "ESP8266"
#define CONTAINER_NAME "HR"

#define ACTUATION "Actuation"
#define MONITOR "Monitor"
#define SUB "Sub"